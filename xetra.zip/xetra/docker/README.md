# Docker Demo

```
cp ../config/config.example.yaml ../config/config.yaml
docker compose up --build
```

Runs a full HUNT->HARDEN->RESPOND->RECOVER->ATTEST cycle every 5 minutes
against mock adapters (zero credentials needed). Evidence lands in the
`xetra-evidence` named volume; `docker compose exec xetra ls evidence_output/`
to inspect, or `docker cp` a file out and open it in `../dashboard/index.html`.
