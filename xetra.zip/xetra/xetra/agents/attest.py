"""
ATTEST — turns a complete HUNT/HARDEN/RESPOND/RECOVER cycle into a
certification-ready evidence package, cross-walked to the control
frameworks in docs/CONTROL_MAPPING.md (SOC2 / ISO 27001 / PCI DSS v4.0 /
NIST CSF 2.0 / FedRAMP / NYDFS 23 NYCRR 500 / NY MTL).

This is the one place in XETRA where output is a document, not an
action — by design, consequential sign-off (accepting residual risk,
closing a finding) stays with a named human.
"""
from __future__ import annotations
import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .hunt import HuntFinding
from .harden import RemediationItem
from .respond import ResponseRecord
from .recover import RecoveryRecord


class AttestAgent:
    def __init__(self, output_dir: str = "evidence_output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def package_cycle(
        self,
        findings: list[HuntFinding],
        remediations: list[RemediationItem],
        responses: list[ResponseRecord],
        recoveries: list[RecoveryRecord],
        cycle_label: str = "cycle",
    ) -> Path:
        timestamp = datetime.now(timezone.utc).isoformat()
        package: dict[str, Any] = {
            "program": "XETRA",
            "generated_at": timestamp,
            "cycle_label": cycle_label,
            "summary": {
                "techniques_tested": len(findings),
                "gaps_found": sum(1 for f in findings if f.gap),
                "gaps_remediated_pending_human_approval": len(remediations),
                "responses_triggered": len(responses),
                "recoveries_validated": sum(1 for r in recoveries if not r.still_gapped),
                "recoveries_still_gapped": sum(1 for r in recoveries if r.still_gapped),
            },
            "findings": [asdict(f) for f in findings],
            "remediations": [asdict(r) for r in remediations],
            "responses": [r.__dict__ for r in responses],
            "recoveries": [r.__dict__ for r in recoveries],
            "note": (
                "This package is machine-generated evidence of a XETRA "
                "validation cycle. It is an input to your audit evidence "
                "package (see docs/CONTROL_MAPPING.md), not a substitute "
                "for auditor review or management sign-off."
            ),
        }
        out_path = self.output_dir / f"xetra-attest-{cycle_label}-{timestamp.replace(':', '')}.json"
        out_path.write_text(json.dumps(package, indent=2, default=str))
        return out_path
