"""
XETRA command-line entry point.

Usage:
    python -m xetra.cli run --config config/config.yaml --label weekly-run
    python -m xetra.cli list-ttps --config config/config.yaml
"""
from __future__ import annotations
import argparse
import logging

from .orchestrator import XetraOrchestrator, load_ttp_library
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(prog="xetra", description="XETRA — the structural inverse of ARTEX")
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="Run one full HUNT->HARDEN->RESPOND->RECOVER->ATTEST cycle")
    run_p.add_argument("--config", default="config/config.yaml")
    run_p.add_argument("--label", default="manual")
    run_p.add_argument("--verbose", action="store_true")

    list_p = sub.add_parser("list-ttps", help="List the loaded TTP library")
    list_p.add_argument("--config", default="config/config.yaml")

    args = parser.parse_args()
    logging.basicConfig(
        level=logging.DEBUG if getattr(args, "verbose", False) else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    if args.command == "run":
        orch = XetraOrchestrator(args.config)
        out_path = orch.run_cycle(cycle_label=args.label)
        print(f"\nEvidence package written to: {out_path}\n")
    elif args.command == "list-ttps":
        lib_dir = Path(__file__).parent / "ttp_library"
        all_ttps = load_ttp_library(str(lib_dir / "artex_ttps.yaml"))
        all_ttps += load_ttp_library(str(lib_dir / "attack_enterprise.yaml"))
        total_ids = sum(len(t["attack_ids"]) for t in all_ttps)
        for t in all_ttps:
            print(f"{t['id']:<22} [{t['stratum']:<14}] {', '.join(t['attack_ids'])}")
        print(f"\n{len(all_ttps)} TTP entries, {total_ids} ATT&CK technique IDs total.")


if __name__ == "__main__":
    main()
