# XETRA

**ARTEX, reversed, is XETRA.**

XETRA is a continuous, evidence-generating control-validation orchestrator built as the structural inverse of [ARTEX](https://www.ic3.gov/) — the autonomous offensive agent framework described in FBI FLASH-20261113-001 (13 Nov 2026, TLP:CLEAR). Where ARTEX chains reconnaissance → exploitation → persistence → privilege escalation → lateral movement → exfiltration → C2 into a single breach, XETRA chains **HUNT → HARDEN → RESPOND → RECOVER → ATTEST** into a single, repeatable proof that each of those techniques is caught, contained, and recoverable — across the same 7 strata (infrastructure/network, service, system, protocol, algorithm, software, hardware) that ARTEX attacks.

```
pip install -e .
cp config/config.example.yaml config/config.yaml
python -m xetra.cli run --config config/config.yaml --label first-run
```

That's it — it runs immediately, with **zero credentials and zero external calls**, against deterministic mock data, and produces a real evidence JSON in `evidence_output/`. Nothing in this repo touches a live system unless you explicitly configure a licensed adapter (see **Going Live**, below).

---

## What this is — and isn't

**Is:**
- A real, working Python orchestrator: five agents, pluggable adapters, a TTP library, a CLI, tests, CI.
- A control-validation layer that sits *on top of* licensed security products you already own or can license (BAS, SIEM, SOAR, EDR), asking them to do what they're built and supported to do.
- A certification-evidence generator: every run produces a JSON package cross-walked to SOC 2, ISO 27001, PCI DSS v4.0, NIST CSF 2.0, FedRAMP, NYDFS §500, and NY MTL (`docs/CONTROL_MAPPING.md`).

**Isn't:**
- Not a fork, wrapper, or port of ARTEX. No exploitation logic exists anywhere in this codebase — not in the mock adapters (deterministic simulated outcomes), not in the "live" adapters (which only call each vendor's own documented, licensed scenario/test API; the vendor's platform owns the actual technique implementation).
- Not something that runs against a target without configuration. Every live adapter raises a clear `RuntimeError` naming exactly what's missing rather than silently doing anything.
- Not a replacement for a licensed BAS/SIEM/SOAR/EDR platform — it's the glue that runs them on a schedule and turns their output into one coherent, auditable cycle.

---

## Architecture

See `docs/ARCHITECTURE.md` for the full diagram and design rationale. Summary:

| Agent | Inverse of (ARTEX) | What it does |
|---|---|---|
| **HUNT** | recon + exploit agents | Runs each ATT&CK-mapped technique via your licensed BAS platform; checks your SIEM for an alert |
| **HARDEN** | persistence + privesc agents | Turns every gap into a `RemediationItem`, flagged for human approval |
| **RESPOND** | lateral movement + C2 agents | Triggers a named SOAR playbook (isolate/revoke/rotate/block) |
| **RECOVER** | collection + exfil agents | Re-runs HUNT on the remediated technique to confirm the gap closed |
| **ATTEST** | (ARTEX leaves forensic noise; XETRA leaves evidence by design) | Packages the full cycle as certification-ready JSON |

```
xetra/
├── xetra/
│   ├── orchestrator.py        # wires config -> adapters -> agents, runs one cycle
│   ├── cli.py                 # `xetra run`, `xetra list-ttps`
│   ├── agents/                # hunt.py, harden.py, respond.py, recover.py, attest.py
│   ├── adapters/
│   │   ├── bas/                # base.py, mock.py, attackiq.py
│   │   ├── siem/               # base.py, mock.py, splunk.py
│   │   ├── soar/                # base.py, mock.py, tines.py
│   │   └── edr/                  # base.py, mock.py, crowdstrike.py
│   └── ttp_library/
│       └── artex_ttps.yaml     # the FBI-advisory TTP catalog, as ATT&CK IDs
├── config/config.example.yaml
├── docs/ARCHITECTURE.md, CONTROL_MAPPING.md
├── tests/
└── .github/workflows/ci.yml
```

---

## The TTP Library

`xetra/ttp_library/artex_ttps.yaml` encodes every phase of the ARTEX kill chain from the FBI advisory as MITRE ATT&CK technique IDs — the same identifiers every major BAS platform already uses to select its own pre-built, safe emulation module. Nothing beyond the ID, stratum, and expected control lives in this file. Run `python -m xetra.cli list-ttps` to see it.

| ARTEX phase | XETRA TTP entry | Stratum |
|---|---|---|
| Reconnaissance | `artex-recon-01` | infra_network |
| Initial Access | `artex-access-01` | service |
| Persistence | `artex-persist-01` | system |
| Privilege Escalation | `artex-privesc-01` | system |
| Internal Recon (incl. EDR-gap mapping) | `artex-discovery-01` | system |
| Lateral Movement | `artex-lateral-01` | system |
| Collection / Exfil Prep | `artex-collect-01` | service |
| Command and Control | `artex-c2-01` | protocol |
| LLM-API egress (ARTEX's signature fingerprint) | `artex-llm-egress-01` | infra_network |

The **program-level signature exercise**: replay this entire table as one BAS campaign, quarterly. Success = every phase caught before privilege escalation completes. This is the literal, direct antidote test.

---

## Going Live

Each stratum can go live independently. None of this is required to use XETRA in mock mode.

| Stratum | Provider | Requirements |
|---|---|---|
| BAS | AttackIQ | License (free Community Edition available), `ATTACKIQ_BASE_URL` + `ATTACKIQ_API_TOKEN`, an Assessment built per technique, mapped in `config.yaml` |
| SIEM | Splunk | `SPLUNK_BASE_URL` + `SPLUNK_TOKEN`, an SPL query per technique in `config.yaml` |
| SOAR | Tines | A Story per playbook, its webhook URL in `config.yaml` |
| EDR | CrowdStrike Falcon | `FALCON_CLIENT_ID` + `FALCON_CLIENT_SECRET` with `hosts:read` + `real-time-response:write` scopes |

**Before flipping anything to live:** fill in `scope.authorized_by` and `scope.targets` in `config.yaml` with your actual signed Rules of Engagement. BAS platforms enforce their own authorization model on top of this — XETRA's scope config is passed through to them, not a substitute for it.

Pluggable adapter interfaces (`adapters/*/base.py`) mean Pentera, SafeBreach, Cymulate, Microsoft Sentinel/Defender, Elastic, or Palo Alto XSOAR can be added as siblings to the existing stubs without touching the orchestrator or agents — contributions welcome.

---

## Testing

```
pip install -r requirements-dev.txt
pytest tests/ -v
```

All tests run against mock adapters — no credentials, no network calls, no risk. CI (`.github/workflows/ci.yml`) runs this plus a full end-to-end CLI smoke test on every push, across Python 3.10–3.12.

---

## Certification Evidence

See `docs/CONTROL_MAPPING.md`. Every ATTEST output is a JSON package: findings, remediations, responses, recoveries, and a summary block — designed to be the machine-generated input to your audit evidence package, not a replacement for auditor review or management sign-off (consequential decisions stay with named humans throughout the loop — see `agents/harden.py` and `agents/attest.py` docstrings).

---

## Why "XETRA"

Not a backronym stretched to fit — reverse the five letters of ARTEX and you get XETRA. The name *is* the thesis: everything ARTEX automates toward compromise, XETRA automates toward proof that compromise doesn't land.

## License

MIT — see `LICENSE`.

## Responsible Use

This project automates licensed, authorized security-validation tooling. It does not contain, depend on, or interoperate with ARTEX or any unlicensed offensive framework. Contributions that add exploitation logic rather than orchestration of a licensed vendor's own API will not be accepted.
